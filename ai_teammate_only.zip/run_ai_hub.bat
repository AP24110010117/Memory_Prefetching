@echo off
echo Starting AI-TeamMate Web Hub...
python ai_teammate/server.py
pause
