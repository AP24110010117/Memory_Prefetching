"""
server.py — Dedicated Web Server & API for the AI-TeamMate Collaborative Platform.

Exposes:
  - GET  /                           -> AI-TeamMate Dashboard
  - GET  /api/team/members           -> Team members metadata
  - GET  /api/team/tasks             -> Shared task list
  - POST /api/team/tasks/add         -> Create a new task
  - POST /api/team/tasks/update      -> Update task status
  - GET  /api/team/activity          -> Real-time activity log
  - GET  /api/team/chat              -> Shared conversation history
  - POST /api/team/chat              -> Send instruction to AI-TeamMate Brain
  - GET  /api/team/files             -> Project file explorer
  - GET  /api/team/file/read         -> Read file content
  - GET  /api/team/viva              -> Viva Voce questions & answers
  - POST /api/team/test/run          -> Run integration test suite
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from flask import Flask, jsonify, request, send_from_directory

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from ai_teammate.brain import AITeamMateBrain

app = Flask(__name__, static_folder=None)
brain = AITeamMateBrain(ROOT)


@app.after_request
def add_cors(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
    return response


@app.get("/")
def home():
    return send_from_directory(Path(__file__).resolve().parent, "dashboard.html")


@app.get("/api/team/members")
def get_members():
    return jsonify(brain.collab.get_members())


@app.get("/api/team/tasks")
def get_tasks():
    return jsonify(brain.collab.get_tasks())


@app.post("/api/team/tasks/add")
def add_task():
    data = request.get_json(force=True) or {}
    title = data.get("title", "Untitled Task")
    assignee = data.get("assignee", "ai_teammate")
    priority = data.get("priority", "medium")
    details = data.get("details", "")
    new_t = brain.collab.add_task(title, assignee, priority, details)
    return jsonify(new_t), 201


@app.post("/api/team/tasks/update")
def update_task():
    data = request.get_json(force=True) or {}
    task_id = data.get("task_id")
    status = data.get("status", "in_progress")
    author = data.get("author_id", "ai_teammate")
    updated = brain.collab.update_task_status(task_id, status, author)
    if updated:
        return jsonify(updated)
    return jsonify({"error": f"Task {task_id} not found"}), 404


@app.get("/api/team/activity")
def get_activity():
    return jsonify(brain.collab.get_activities())


@app.get("/api/team/chat")
def get_chat():
    return jsonify(brain.collab.get_chat_history())


@app.post("/api/team/chat")
def send_chat():
    data = request.get_json(force=True) or {}
    prompt = data.get("prompt", "")
    author_id = data.get("author_id", "member_1")
    if not prompt.strip():
        return jsonify({"error": "Prompt cannot be empty"}), 400

    result = brain.execute_prompt(prompt, author_id)
    return jsonify(result)


@app.get("/api/team/files")
def list_files():
    rel = request.args.get("dir", "")
    return jsonify(brain.analyzer.list_files(rel))


@app.get("/api/team/file/read")
def read_file_content():
    path = request.args.get("path", "")
    return jsonify(brain.coding.read_file(path))


@app.get("/api/team/viva")
def get_viva():
    return jsonify(brain.doc.get_viva_guide())


@app.post("/api/team/test/run")
def run_tests():
    return jsonify(brain.testing.run_all_tests())


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5050))
    print(f"AI-TeamMate Collaborative Platform active at: http://127.0.0.1:{port}")
    app.run(host="127.0.0.1", port=port, debug=False)
