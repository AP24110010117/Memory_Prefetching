"""
coding_agent.py — Code Generation, Safe Editing & File Management for AI-TeamMate.

Provides:
  - Reading files with line numbers
  - Syntax-checked code editing (AST verification for Python)
  - Automatic backup creation before destructive edits
  - Safe creation of new project files
"""
from __future__ import annotations

import ast
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parent.parent


class CodingAgent:
    """Applies code edits, creates helper scripts, and guarantees Python syntax validity."""

    def __init__(self, root_dir: Optional[Path] = None):
        self.root = root_dir or ROOT
        self.backup_dir = self.root / ".ai_backups"
        self.backup_dir.mkdir(exist_ok=True)

    def read_file(self, file_path_str: str, start_line: int = 1, end_line: Optional[int] = None) -> Dict[str, Any]:
        """Read a file's contents with line ranges."""
        p = self.root / file_path_str
        if not p.exists():
            return {"error": f"File does not exist: {file_path_str}"}

        try:
            content = p.read_text(encoding="utf-8", errors="replace")
            lines = content.splitlines()
            total_lines = len(lines)

            s_idx = max(1, start_line) - 1
            e_idx = min(total_lines, end_line) if end_line else total_lines

            sliced_lines = lines[s_idx:e_idx]
            numbered = [f"{i+1:4d} | {line}" for i, line in enumerate(sliced_lines, start=s_idx)]

            return {
                "file": file_path_str,
                "total_lines": total_lines,
                "start_line": s_idx + 1,
                "end_line": e_idx,
                "content": "\n".join(sliced_lines),
                "numbered_content": "\n".join(numbered)
            }
        except Exception as e:
            return {"error": f"Could not read {file_path_str}: {e}"}

    def edit_file(self, file_path_str: str, target: str, replacement: str) -> Dict[str, Any]:
        """Safely replace code block in file after Python AST verification."""
        p = self.root / file_path_str
        if not p.exists():
            return {"error": f"File does not exist: {file_path_str}"}

        old_text = p.read_text(encoding="utf-8", errors="replace")
        if target not in old_text:
            return {"error": f"Target snippet not found in {file_path_str}. Match whitespace exactly."}

        new_text = old_text.replace(target, replacement, 1)

        # Syntax check if Python
        if p.suffix == ".py":
            try:
                ast.parse(new_text)
            except SyntaxError as e:
                return {
                    "error": f"Proposed edit results in Python SyntaxError: {e}. Edit aborted."
                }

        # Create backup
        backup_p = self.backup_dir / f"{p.name}.bak"
        shutil.copy2(p, backup_p)

        p.write_text(new_text, encoding="utf-8")
        return {
            "status": "success",
            "file": file_path_str,
            "message": f"Successfully updated {file_path_str}",
            "backup": str(backup_p.relative_to(self.root))
        }

    def create_file(self, file_path_str: str, content: str, overwrite: bool = False) -> Dict[str, Any]:
        """Create a new file with parent directories."""
        p = self.root / file_path_str
        if p.exists() and not overwrite:
            return {"error": f"File {file_path_str} already exists. Pass overwrite=True."}

        if p.suffix == ".py":
            try:
                ast.parse(content)
            except SyntaxError as e:
                return {"error": f"Proposed file has Python SyntaxError: {e}. Creation aborted."}

        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return {
            "status": "success",
            "file": file_path_str,
            "bytes_written": len(content.encode("utf-8"))
        }
