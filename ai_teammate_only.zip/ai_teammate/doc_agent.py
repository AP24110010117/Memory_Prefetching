"""
doc_agent.py — Documentation & Viva Voce Preparation Specialist for AI-TeamMate.

Provides:
  - Automated project report generation
  - Viva Voce (oral exam) questions and model answers
  - Architecture summaries and concept breakdowns
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parent.parent


class DocumentationAgent:
    """Specialized AI Agent for Project Reports, Documentation, and Viva Voce Preparation."""

    def __init__(self, root_dir: Optional[Path] = None):
        self.root = root_dir or ROOT

    def get_viva_guide(self) -> List[Dict[str, str]]:
        """Return high-frequency viva exam questions with examiner-grade model answers."""
        return [
            {
                "topic": "The Memory Wall & Prefetching",
                "question": "What is the memory wall problem, and why is machine learning needed for prefetching?",
                "answer": (
                    "The memory wall refers to the growing performance gap between rapid CPU clock rates and slow DRAM access latencies (~200 CPU cycles). "
                    "Traditional hardware prefetchers rely on rigid heuristics: a Next-Line prefetcher naively assumes block b+1 will be needed, failing on strided or reverse loops (achieving only ~25% accuracy). "
                    "Machine learning models can learn complex spatial-temporal patterns, recognizing strides (+2, +4, +8, +16, -1, -2) and pointer chasing across interleaved memory streams."
                )
            },
            {
                "topic": "Average Memory Access Time (AMAT)",
                "question": "How is AMAT mathematically computed, and what improvement did your project achieve?",
                "answer": (
                    "AMAT = Hit_Time_L1 + Miss_Rate_L1 * (Hit_Time_L2 + Miss_Rate_L2 * (Hit_Time_L3 + Miss_Rate_L3 * Latency_DRAM)). "
                    "In our hardware simulation, baseline demand-only execution required 191.30 cycles per access. "
                    "With our adaptive ML prefetcher and congestion control, AMAT dropped to 109.85 cycles — an 81.45 cycle reduction (42.6% latency savings)."
                )
            },
            {
                "topic": "Lightweight On-Chip Hardware MLP",
                "question": "How can an AI model run inside a CPU cache controller without adding massive latency?",
                "answer": (
                    "Instead of a large neural network, we designed a Compact Deep MLP (32–16) with 30 inputs, two hidden layers (32 and 16 neurons with ReLU), and 10 Softmax outputs. "
                    "The model contains exactly 1,690 weights. Under 32-bit floating point precision, this requires only 6.60 KB of SRAM storage, fitting directly into on-die cache controller tables. "
                    "Its inference latency is only 2.3 microseconds per access, delivering 94.88% test accuracy without DRAM stalls."
                )
            },
            {
                "topic": "Virtual Page Boundary Protection",
                "question": "Why can prefetching across a 4 KB page boundary crash a program, and how does your project prevent it?",
                "answer": (
                    "Virtual memory is divided into 4 KB pages (64 cache lines of 64 bytes). The CPU's Translation Lookaside Buffer (TLB) translates virtual to physical page frames. "
                    "If a prefetch crosses into the next page before that page is mapped, it can trigger an expensive OS Page Fault or memory protection fault. "
                    "Our Page Manager enforces: delta <= (63 - page_offset) for forward prefetching and delta >= -page_offset for reverse prefetching. "
                    "In testing, 334 unsafe cross-page hazards were successfully intercepted."
                )
            },
            {
                "topic": "Data Leakage & Causal Integrity",
                "question": "How do you prove that your 95% model accuracy is genuine and not caused by data leakage?",
                "answer": (
                    "We implemented 6 automated leakage checks: "
                    "1) Strict 70/10/20 chronological splitting without shuffling. "
                    "2) Removal of static Program Counter (PC) memorization so the model learns access dynamics, not synthetic PC IDs. "
                    "3) All delta features strictly use past causal lags (t-1, t-2, t-3, t-4) with zero future lookahead. "
                    "4) Evaluation on an independent out-of-distribution workload (Seed 999) achieved 95.05% accuracy, proving true generalization."
                )
            },
            {
                "topic": "Dynamic Congestion Routing",
                "question": "What is cache pollution, and how does your adaptive prefetcher prevent it?",
                "answer": (
                    "Cache pollution occurs when inaccurate or prematurely prefetched lines evict useful data currently needed by the CPU. "
                    "We solve this in two ways: "
                    "1) Confidence gating: prefetches are only issued if model confidence >= tau (0.40). "
                    "2) Dynamic congestion routing: if L1 occupancy is >= 95%, prefetches are dynamically routed to L2 cache rather than L1, protecting L1 from thrashing while staging data close to the core."
                )
            }
        ]

    def generate_project_report(self) -> str:
        """Generate a complete Markdown project report."""
        report = []
        report.append("# ML-Based Hardware Memory Prefetching — Executive Project Report\n")
        report.append("## 1. Abstract")
        report.append("This project presents an intelligent memory prefetching architecture that integrates machine learning with virtual page awareness, segment limits, and multi-level cache congestion control. The system achieves 95.23% stride prediction accuracy, reduces Average Memory Access Time (AMAT) from 191.30 to 109.85 cycles (a 42.6% latency reduction), and eliminates 100% of speculative page-crossing faults.\n")
        report.append("## 2. Team Member Contributions")
        report.append("- **Member 1 (ML Specialist)**: Dataset generation, causal lag engineering, model zoo (DT, RF, GB, Compact MLP 32-16).")
        report.append("- **Member 2 (Cache/COA Specialist)**: Multi-level cache simulation (L1/L2/L3/DRAM), AMAT modeling, dynamic congestion routing.")
        report.append("- **Member 3 (Backend Developer)**: Flask REST API, live prediction endpoints (`/api/predict`, `/api/simulate`), error handling.")
        report.append("- **Member 4 (Frontend Developer)**: Enterprise dashboard, live REST API tester, visual cache scrubber, SVG metric charts.")
        report.append("- **Member 5 (Integration & QA Lead)**: Automated regression testing suite (`test_integration.py`), data leakage verification.")
        report.append("- **AI-TeamMate (6th Member)**: Autonomous development partner, continuous diagnostics, repository analysis, and collaborative workspace engine.\n")
        return "\n".join(report)
