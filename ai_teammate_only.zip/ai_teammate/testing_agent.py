"""
testing_agent.py — Automated Test Runner & Diagnostics Specialist for AI-TeamMate.

Provides:
  - Running automated integration test suite (test_integration.py)
  - Live backend REST endpoint probing
  - Inference latency benchmarking
  - Self-healing checks
"""
from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parent.parent


class TestingAgent:
    """Specialized AI Agent for Continuous Testing, Verification, and Error Diagnostics."""

    def __init__(self, root_dir: Optional[Path] = None):
        self.root = root_dir or ROOT

    def run_all_tests(self) -> Dict[str, Any]:
        """Execute the automated test_integration.py suite."""
        t0 = time.time()
        res = subprocess.run(
            [sys.executable, "test_integration.py"],
            cwd=self.root,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace"
        )
        duration = round(time.time() - t0, 3)

        passed = res.returncode == 0
        output = (res.stdout + "\n" + res.stderr).strip()

        # Parse test results
        test_cases = []
        for line in output.splitlines():
            if " ... " in line:
                parts = line.split(" ... ")
                test_cases.append({
                    "name": parts[0].strip(),
                    "status": parts[1].strip()
                })

        return {
            "all_passed": passed,
            "duration_sec": duration,
            "exit_code": res.returncode,
            "tests_found": len(test_cases),
            "test_cases": test_cases,
            "raw_output": output
        }

    def probe_backend_endpoints(self) -> Dict[str, Any]:
        """Probe the Flask backend app via Flask test client without needing a running port."""
        try:
            from backend.app import app
            client = app.test_client()

            # 1. Health
            r_health = client.get("/api/health")
            # 2. Results
            r_results = client.get("/api/results")
            # 3. Predict
            r_predict = client.post("/api/predict", json={
                "pc": "0x004010A0",
                "address": "0x10001000",
                "segment": "DATA",
                "delta_history": [4, 4, 4, 4]
            })
            # 4. Simulate
            r_simulate = client.post("/api/simulate", json={
                "pattern": "stride",
                "length": 50
            })

            return {
                "health_status": r_health.status_code,
                "health_payload": r_health.get_json(),
                "results_status": r_results.status_code,
                "predict_status": r_predict.status_code,
                "predict_payload": r_predict.get_json(),
                "simulate_status": r_simulate.status_code,
                "all_endpoints_healthy": all(
                    s == 200 for s in [
                        r_health.status_code,
                        r_results.status_code,
                        r_predict.status_code,
                        r_simulate.status_code
                    ]
                )
            }
        except Exception as e:
            return {"error": f"Failed probing backend: {e}", "all_endpoints_healthy": False}
