"""
AI-TeamMate: Autonomous AI-Powered 6th Team Member for Memory Prefetching Project.
Acts as a senior co-developer capable of repository analysis, ML training, cache simulation,
backend API development, automated testing, and multi-member team collaboration.
"""

from .brain import AITeamMateBrain
from .repository_analyzer import RepositoryAnalyzer
from .coding_agent import CodingAgent
from .ml_agent import MLAgent
from .cache_agent import CacheAgent
from .testing_agent import TestingAgent
from .integration_agent import IntegrationAgent
from .doc_agent import DocumentationAgent
from .team_collaboration import TeamCollaborationManager

__version__ = "2.0.0"
__all__ = [
    "AITeamMateBrain",
    "RepositoryAnalyzer",
    "CodingAgent",
    "MLAgent",
    "CacheAgent",
    "TestingAgent",
    "IntegrationAgent",
    "DocumentationAgent",
    "TeamCollaborationManager",
]
