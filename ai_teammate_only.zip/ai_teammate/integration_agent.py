"""
integration_agent.py — Cross-Module Pipeline Integrator for AI-TeamMate.

Provides:
  - Verification of inter-module data contracts
  - Dataset to ML feature dimension matching
  - ML stride class mapping to cache simulator
  - Pipeline export sync between Python results and frontend/data.js
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parent.parent


class IntegrationAgent:
    """Specialized AI Agent for Cross-Module Compatibility and Integration Verification."""

    def __init__(self, root_dir: Optional[Path] = None):
        self.root = root_dir or ROOT

    def verify_pipeline_integrity(self) -> Dict[str, Any]:
        """Perform a rigorous end-to-end data contract check across all 5 modules."""
        issues = []
        checks = []

        # 1. Check config.py parameters
        try:
            import config
            checks.append({
                "component": "config.py",
                "status": "VALID",
                "details": f"Page size: {config.PAGE_SIZE_BYTES}B, Blocks/Page: {config.BLOCKS_PER_PAGE}, Classes: {config.NUM_CLASSES}"
            })
            if config.SEGMENTS["DATA"]["size_kb"] < 4096:
                issues.append("DATA segment size in config.py is below 4096 KB (may cause segment overflows).")
        except Exception as e:
            issues.append(f"Failed loading config.py: {e}")

        # 2. Check ML Scaler & Features
        try:
            import joblib
            scaler = joblib.load(self.root / "models" / "scaler.pkl")
            checks.append({
                "component": "models/scaler.pkl",
                "status": "VALID",
                "details": f"Fitted with {scaler.n_features_in_} features"
            })
        except Exception as e:
            issues.append(f"Failed inspecting scaler: {e}")

        # 3. Check ML Model classes
        try:
            import joblib
            best_model = joblib.load(self.root / "models" / "best_model.pkl")
            checks.append({
                "component": "models/best_model.pkl",
                "status": "VALID",
                "details": f"Model type: {type(best_model).__name__}, Classes: {len(best_model.classes_)}"
            })
        except Exception as e:
            issues.append(f"Failed inspecting best_model: {e}")

        # 4. Check Frontend data.js sync
        try:
            data_js_path = self.root / "frontend" / "data.js"
            if not data_js_path.exists():
                issues.append("frontend/data.js is missing. Run export_data.py.")
            else:
                raw = data_js_path.read_text(encoding="utf-8").strip()
                prefix = "window.PF = "
                if not raw.startswith(prefix):
                    issues.append("frontend/data.js does not start with window.PF = ")
                else:
                    json_str = raw[len(prefix):].rstrip(";\n")
                    data = json.loads(json_str)
                    checks.append({
                        "component": "frontend/data.js",
                        "status": "VALID",
                        "details": f"Summary best_model: {data.get('summary', {}).get('best_model')}, Graphs listed: {len(data.get('graphs', []))}"
                    })
        except Exception as e:
            issues.append(f"Failed reading frontend/data.js: {e}")

        # 5. Check 15 publication graphs
        graph_dir = self.root / "results" / "graphs"
        graph_count = len(list(graph_dir.glob("*.png"))) if graph_dir.exists() else 0
        if graph_count < 15:
            issues.append(f"Expected 15 graphs in results/graphs/, found {graph_count}.")
        else:
            checks.append({
                "component": "results/graphs/",
                "status": "VALID",
                "details": f"All 15 publication figures present"
            })

        return {
            "all_integrated": len(issues) == 0,
            "issues_count": len(issues),
            "issues": issues,
            "verified_checks": checks
        }
