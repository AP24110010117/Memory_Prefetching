"""
cache_agent.py — Computer Architecture & Cache Simulation Assistant for AI-TeamMate.

Provides:
  - Cycle-accurate multi-level cache simulation (L1/L2/L3/DRAM)
  - Hardware AMAT and prefetch metric calculation
  - Virtual 4 KB page boundary safety verification
  - Memory segment (TEXT, DATA, HEAP, STACK) boundary validation
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import config
import joblib
import numpy as np
import pandas as pd


class CacheAgent:
    """Specialized AI Agent for Cache Simulation, Memory Subsystem, and Hardware Safety."""

    def __init__(self, root_dir: Optional[Path] = None):
        self.root = root_dir or ROOT

    def run_simulation(self, tau: Optional[float] = None) -> Dict[str, Any]:
        """Run cycle-accurate prefetch simulation on the test trace."""
        from src.adaptive_prefetching import AdaptivePrefetcher
        from src.generate_dataset import get_feature_columns

        best_path = self.root / "models" / "best_model.pkl"
        scaler_path = self.root / "models" / "scaler.pkl"
        model = joblib.load(best_path)
        scaler = joblib.load(scaler_path)

        df_test = pd.read_csv(config.TEST_CSV)
        feat_cols = get_feature_columns(df_test)

        prefetcher = AdaptivePrefetcher(model, scaler, threshold=tau or config.DEFAULT_CONFIDENCE_THRESHOLD)
        _, bl_m, ad_m = prefetcher.simulate_trace(df_test, feat_cols)

        return {
            "baseline": {
                "l1_hit_rate_pct": round(bl_m["l1_hit_rate_pct"], 2),
                "overall_hit_rate_pct": round(bl_m["overall_hit_rate_pct"], 2),
                "amat_cycles": round(bl_m["amat_cycles"], 2),
            },
            "adaptive": {
                "l1_hit_rate_pct": round(ad_m["l1_hit_rate_pct"], 2),
                "overall_hit_rate_pct": round(ad_m["overall_hit_rate_pct"], 2),
                "amat_cycles": round(ad_m["amat_cycles"], 2),
                "coverage_pct": round(ad_m["coverage_pct"], 2),
                "useful_precision_pct": round(ad_m["useful_precision_pct"], 2),
                "prefetches_issued": ad_m["pf_issued"],
                "timely_hits": ad_m["pf_timely"],
                "late_hits": ad_m["pf_late"],
                "unused_evicted": ad_m["pf_unused"],
                "page_hazards_blocked": ad_m["boundary_stats"]["page_blocked"],
                "segment_overflows_blocked": ad_m["boundary_stats"]["seg_blocked"]
            },
            "gain": {
                "hit_rate_improvement_pct": round(ad_m["overall_hit_rate_pct"] - bl_m["overall_hit_rate_pct"], 2),
                "amat_latency_reduction_cycles": round(bl_m["amat_cycles"] - ad_m["amat_cycles"], 2)
            }
        }

    def validate_safety_suite(self) -> Dict[str, Any]:
        """Execute the 12-case page and segment boundary verification suite."""
        from simulation.page_manager import run_boundary_test_suite
        df_tests = run_boundary_test_suite()

        passed = int((df_tests["status"] == "PASSED").sum())
        total = len(df_tests)

        cases = []
        for _, row in df_tests.iterrows():
            cases.append({
                "test_case": row["test_case"],
                "stride_delta": int(row["stride_delta"]),
                "page_offset": int(row["page_offset"]),
                "expected": row["expected"],
                "result": row["result"],
                "status": row["status"]
            })

        return {
            "total_cases": total,
            "passed_cases": passed,
            "pass_rate_pct": round(passed / total * 100, 2),
            "cases": cases
        }
