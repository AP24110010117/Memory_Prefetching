"""
repository_analyzer.py — Deep Codebase Inspector & Static Analyzer for AI-TeamMate.

Provides:
  - Full directory & file tree scanning
  - Python AST function and class extraction
  - Fast keyword and regex code search across the repository
  - Model weights and dataset inspection
  - Dependency verification
"""
from __future__ import annotations

import ast
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parent.parent


class RepositoryAnalyzer:
    """Understands, searches, and monitors the complete Memory Prefetching repository."""

    def __init__(self, root_dir: Optional[Path] = None):
        self.root = root_dir or ROOT

    def get_overview(self) -> Dict[str, Any]:
        """Return a structured overview of the entire project."""
        py_files = list(self.root.rglob("*.py"))
        csv_files = list((self.root / "data").glob("*.csv"))
        model_files = list((self.root / "models").glob("*.pkl"))
        graph_files = list((self.root / "results" / "graphs").glob("*.png"))

        # Exclude git & pycache
        py_clean = [p for p in py_files if ".git" not in str(p) and "__pycache__" not in str(p)]

        total_lines = 0
        for p in py_clean:
            try:
                total_lines += sum(1 for _ in open(p, encoding="utf-8", errors="ignore"))
            except Exception:
                pass

        return {
            "root": str(self.root),
            "python_files_count": len(py_clean),
            "total_python_lines": total_lines,
            "datasets_count": len(csv_files),
            "models_count": len(model_files),
            "publication_figures_count": len(graph_files),
            "modules": {
                "ml": ["src/train_models.py", "src/mlp_model.py", "src/generate_dataset.py", "src/leakage_checker.py"],
                "cache": ["src/cache_simulator.py", "src/adaptive_prefetching.py"],
                "safety": ["simulation/page_manager.py", "simulation/segment_manager.py"],
                "backend": ["backend/app.py", "backend/export_data.py"],
                "frontend": ["frontend/index.html", "frontend/data.js"],
                "integration": ["main.py", "test_integration.py", "export_data.py"],
                "ai_teammate": ["ai_teammate/"]
            }
        }

    def list_files(self, relative_dir: str = "") -> List[Dict[str, Any]]:
        """List files and directories in a given relative path."""
        target_dir = self.root / relative_dir if relative_dir else self.root
        if not target_dir.exists():
            return []

        entries = []
        for item in sorted(target_dir.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
            if item.name.startswith(".") and item.name not in [".vscode"]:
                continue
            if item.name in ["__pycache__", ".git"]:
                continue

            rel_path = item.relative_to(self.root).as_posix()
            is_dir = item.is_dir()
            size = item.stat().st_size if not is_dir else 0

            entries.append({
                "name": item.name,
                "path": rel_path,
                "is_dir": is_dir,
                "size_bytes": size,
                "size_display": f"{size/1024:.1f} KB" if size >= 1024 else f"{size} B" if not is_dir else "-"
            })
        return entries

    def search_code(self, query: str, file_ext: str = ".py") -> List[Dict[str, Any]]:
        """Search for a keyword or regex across all project files."""
        results = []
        clean_ext = file_ext if file_ext.startswith(".") else f".{file_ext}"

        for file_path in self.root.rglob(f"*{clean_ext}"):
            if ".git" in str(file_path) or "__pycache__" in str(file_path):
                continue

            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
                lines = content.splitlines()
                for line_idx, line in enumerate(lines, 1):
                    if query.lower() in line.lower():
                        results.append({
                            "file": file_path.relative_to(self.root).as_posix(),
                            "line_number": line_idx,
                            "line_content": line.strip()[:160]
                        })
            except Exception:
                continue

        return results[:100]

    def extract_symbols(self, file_path_str: str) -> Dict[str, Any]:
        """Extract classes, functions, and imports from a Python file using AST."""
        p = self.root / file_path_str
        if not p.exists() or p.suffix != ".py":
            return {"error": f"File not found or not Python: {file_path_str}"}

        try:
            tree = ast.parse(p.read_text(encoding="utf-8", errors="ignore"))
        except Exception as e:
            return {"error": f"Syntax error parsing {file_path_str}: {e}"}

        classes = []
        functions = []
        imports = []

        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                classes.append({"name": node.name, "line": node.lineno})
            elif isinstance(node, ast.FunctionDef):
                functions.append({"name": node.name, "line": node.lineno})
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append(alias.name)
            elif isinstance(node, ast.ImportFrom):
                mod = node.module or ""
                for alias in node.names:
                    imports.append(f"{mod}.{alias.name}")

        return {
            "file": file_path_str,
            "classes": classes,
            "functions": functions,
            "imports": sorted(list(set(imports)))
        }

    def inspect_models(self) -> List[Dict[str, Any]]:
        """Inspect all trained models in models/."""
        import joblib
        res = []
        for p in sorted((self.root / "models").glob("*.pkl")):
            item = {
                "name": p.name,
                "size_kb": round(p.stat().st_size / 1024, 2),
                "modified": p.stat().st_mtime
            }
            try:
                obj = joblib.load(p)
                item["type"] = type(obj).__name__
                if hasattr(obj, "classes_"):
                    item["num_classes"] = len(obj.classes_)
                if hasattr(obj, "n_features_in_"):
                    item["num_features"] = obj.n_features_in_
            except Exception as e:
                item["load_error"] = str(e)
            res.append(item)
        return res

    def inspect_datasets(self) -> List[Dict[str, Any]]:
        """Inspect all CSV datasets in data/."""
        import pandas as pd
        res = []
        for p in sorted((self.root / "data").glob("*.csv")):
            item = {
                "name": p.name,
                "size_kb": round(p.stat().st_size / 1024, 2),
            }
            try:
                df = pd.read_csv(p, nrows=2)
                item["columns"] = list(df.columns)
                item["num_columns"] = len(df.columns)
                # Count lines without loading full df in RAM
                rows = sum(1 for _ in open(p, encoding="utf-8", errors="ignore")) - 1
                item["row_count"] = rows
            except Exception as e:
                item["read_error"] = str(e)
            res.append(item)
        return res
