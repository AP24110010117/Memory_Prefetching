"""
team_collaboration.py — Multi-Member Collaboration & Workspace State Manager.

Maintains:
  - 5 Student Team Member Profiles + AI-TeamMate (6th Member)
  - Shared Collaborative Task Board (Kanban style: todo, in_progress, review, completed)
  - Real-time Activity Audit Trail
  - Shared AI Context & Conversation History
"""
from __future__ import annotations

import json
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parent.parent


class TeamCollaborationManager:
    """Manages 5-member student team collaboration, shared tasks, and activity logs."""

    MEMBERS = {
        "member_1": {
            "id": "member_1",
            "name": "Member 1 (ML Specialist)",
            "role": "Machine Learning Engineer",
            "ownership": ["src/train_models.py", "src/mlp_model.py", "models/"],
            "color": "#2f6fed"
        },
        "member_2": {
            "id": "member_2",
            "name": "Member 2 (Cache & COA Specialist)",
            "role": "Computer Architecture & Cache Engineer",
            "ownership": ["src/cache_simulator.py", "src/adaptive_prefetching.py", "simulation/"],
            "color": "#1a9e5c"
        },
        "member_3": {
            "id": "member_3",
            "name": "Member 3 (Backend Developer)",
            "role": "Backend Systems & REST API Engineer",
            "ownership": ["backend/app.py", "backend/export_data.py"],
            "color": "#d98a1f"
        },
        "member_4": {
            "id": "member_4",
            "name": "Member 4 (Frontend Developer)",
            "role": "Frontend & UI/UX Engineer",
            "ownership": ["frontend/index.html", "frontend/data.js"],
            "color": "#7b5cf0"
        },
        "member_5": {
            "id": "member_5",
            "name": "Member 5 (Integration & QA Lead)",
            "role": "Integration & Testing Lead",
            "ownership": ["main.py", "test_integration.py", "export_data.py"],
            "color": "#d6453d"
        },
        "ai_teammate": {
            "id": "ai_teammate",
            "name": "AI-TeamMate",
            "role": "Autonomous 6th Team Member / Senior Architect",
            "ownership": ["ai_teammate/", "All Modules (Co-developer)"],
            "color": "#00b4d8"
        }
    }

    def __init__(self, root_dir: Optional[Path] = None):
        self.root = root_dir or ROOT
        self.state_dir = self.root / "data" / "collaboration"
        self.state_dir.mkdir(parents=True, exist_ok=True)

        self.tasks_file = self.state_dir / "tasks.json"
        self.activity_file = self.state_dir / "activity.json"
        self.chat_file = self.state_dir / "shared_chat.json"

        self._init_defaults()

    def _init_defaults(self):
        """Seed default tasks and activities if not existing."""
        if not self.tasks_file.exists():
            default_tasks = [
                {
                    "id": "TASK-101",
                    "title": "Train Compact Deep MLP (32-16) for on-chip deployment",
                    "assignee": "member_1",
                    "status": "completed",
                    "priority": "high",
                    "created_at": "2026-11-18T10:00:00",
                    "updated_at": "2026-11-18T22:30:00",
                    "details": "Tuned Compact MLP to 6.60 KB with 94.88% test accuracy."
                },
                {
                    "id": "TASK-102",
                    "title": "Fix DATA segment overflow & implement L1/L2 congestion routing",
                    "assignee": "member_2",
                    "status": "completed",
                    "priority": "critical",
                    "created_at": "2026-11-18T11:00:00",
                    "updated_at": "2026-11-18T23:05:00",
                    "details": "Expanded DATA size to 4096 KB (100% in-range); routed L1 congestion to L2."
                },
                {
                    "id": "TASK-103",
                    "title": "Build real-time REST API endpoints (/api/predict, /api/simulate)",
                    "assignee": "member_3",
                    "status": "completed",
                    "priority": "high",
                    "created_at": "2026-11-18T14:00:00",
                    "updated_at": "2026-11-18T23:15:00",
                    "details": "Endpoints added with 30-feature extraction and safety checks."
                },
                {
                    "id": "TASK-104",
                    "title": "Enterprise UI Dashboard with Live REST API Tester",
                    "assignee": "member_4",
                    "status": "completed",
                    "priority": "medium",
                    "created_at": "2026-11-18T16:00:00",
                    "updated_at": "2026-11-18T23:40:00",
                    "details": "Interactive canvas, SVG charts, and live REST testing panel added."
                },
                {
                    "id": "TASK-105",
                    "title": "End-to-end integration and automated regression suite",
                    "assignee": "member_5",
                    "status": "completed",
                    "priority": "critical",
                    "created_at": "2026-11-18T18:00:00",
                    "updated_at": "2026-11-19T00:10:00",
                    "details": "Author test_integration.py; 5/5 integration tests passing."
                },
                {
                    "id": "TASK-106",
                    "title": "Deploy AI-TeamMate Autonomous Agent & Collaboration Hub",
                    "assignee": "ai_teammate",
                    "status": "in_progress",
                    "priority": "critical",
                    "created_at": "2026-11-19T09:00:00",
                    "updated_at": "2026-11-19T10:30:00",
                    "details": "Build autonomous 6th team member engine with CLI and Web interface."
                }
            ]
            self.tasks_file.write_text(json.dumps(default_tasks, indent=2), encoding="utf-8")

        if not self.activity_file.exists():
            default_activity = [
                {
                    "timestamp": datetime.now().isoformat(),
                    "author": "ai_teammate",
                    "author_name": "AI-TeamMate",
                    "action": "Joined Project",
                    "details": "Initialized as the autonomous 6th team member."
                }
            ]
            self.activity_file.write_text(json.dumps(default_activity, indent=2), encoding="utf-8")

        if not self.chat_file.exists():
            default_chat = [
                {
                    "id": "msg-1",
                    "timestamp": datetime.now().isoformat(),
                    "sender": "ai_teammate",
                    "sender_name": "AI-TeamMate",
                    "role": "assistant",
                    "text": "Hello team! I am AI-TeamMate, your 6th team member. I have fully indexed our Memory Prefetching repository. Ask me to train models, simulate caches, inspect files, debug backend APIs, run tests, or explain concepts for your viva!"
                }
            ]
            self.chat_file.write_text(json.dumps(default_chat, indent=2), encoding="utf-8")

    def get_members(self) -> Dict[str, Any]:
        return self.MEMBERS

    def get_tasks(self) -> List[Dict[str, Any]]:
        try:
            return json.loads(self.tasks_file.read_text(encoding="utf-8"))
        except Exception:
            return []

    def save_tasks(self, tasks: List[Dict[str, Any]]) -> None:
        self.tasks_file.write_text(json.dumps(tasks, indent=2), encoding="utf-8")

    def add_task(self, title: str, assignee: str = "ai_teammate", priority: str = "medium", details: str = "") -> Dict[str, Any]:
        tasks = self.get_tasks()
        task_id = f"TASK-{len(tasks) + 101}"
        new_task = {
            "id": task_id,
            "title": title,
            "assignee": assignee if assignee in self.MEMBERS else "ai_teammate",
            "status": "todo",
            "priority": priority,
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "details": details
        }
        tasks.append(new_task)
        self.save_tasks(tasks)
        self.log_activity(assignee, "Created Task", f"Task {task_id}: {title}")
        return new_task

    def update_task_status(self, task_id: str, new_status: str, author: str = "ai_teammate") -> Optional[Dict[str, Any]]:
        tasks = self.get_tasks()
        target = None
        for t in tasks:
            if t["id"] == task_id:
                t["status"] = new_status
                t["updated_at"] = datetime.now().isoformat()
                target = t
                break
        if target:
            self.save_tasks(tasks)
            self.log_activity(author, "Updated Task", f"{task_id} status changed to {new_status}")
        return target

    def log_activity(self, author_id: str, action: str, details: str) -> None:
        author_meta = self.MEMBERS.get(author_id, self.MEMBERS["ai_teammate"])
        activities = self.get_activities()
        activities.insert(0, {
            "timestamp": datetime.now().isoformat(),
            "author": author_id,
            "author_name": author_meta["name"],
            "action": action,
            "details": details
        })
        # Keep latest 100 activities
        self.activity_file.write_text(json.dumps(activities[:100], indent=2), encoding="utf-8")

    def get_activities(self) -> List[Dict[str, Any]]:
        try:
            return json.loads(self.activity_file.read_text(encoding="utf-8"))
        except Exception:
            return []

    def get_chat_history(self) -> List[Dict[str, Any]]:
        try:
            return json.loads(self.chat_file.read_text(encoding="utf-8"))
        except Exception:
            return []

    def post_chat_message(self, sender_id: str, text: str, role: str = "user") -> Dict[str, Any]:
        history = self.get_chat_history()
        sender_meta = self.MEMBERS.get(sender_id, self.MEMBERS["ai_teammate"])
        msg = {
            "id": f"msg-{int(time.time()*1000)}",
            "timestamp": datetime.now().isoformat(),
            "sender": sender_id,
            "sender_name": sender_meta["name"],
            "role": role,
            "text": text
        }
        history.append(msg)
        self.chat_file.write_text(json.dumps(history[-200:], indent=2), encoding="utf-8")
        return msg
