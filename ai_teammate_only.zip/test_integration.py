"""
test_integration.py — End-to-End System Integration Test Suite.
Verifies all 5 team components: ML, Simulation, Backend, Frontend Data, and Hardware Safety.
"""
import json
import os
import sys
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import config
import joblib
import numpy as np
import pandas as pd


class TestMemoryPrefetchingIntegration(unittest.TestCase):

    def test_01_models_and_scaler_load(self):
        """Verify that all production models and scaler exist and load cleanly."""
        scaler_path = ROOT / "models" / "scaler.pkl"
        self.assertTrue(scaler_path.exists(), "scaler.pkl missing")
        scaler = joblib.load(scaler_path)
        self.assertEqual(scaler.n_features_in_, 30, "Scaler must expect exactly 30 features")

        best_path = ROOT / "models" / "best_model.pkl"
        self.assertTrue(best_path.exists(), "best_model.pkl missing")
        best_model = joblib.load(best_path)
        self.assertTrue(hasattr(best_model, "predict_proba"), "Model must implement predict_proba")

        mlp_path = ROOT / "models" / "mlp_model.pkl"
        self.assertTrue(mlp_path.exists(), "mlp_model.pkl missing")
        mlp_model = joblib.load(mlp_path)
        self.assertTrue(hasattr(mlp_model, "predict_proba"), "Compact MLP must implement predict_proba")

    def test_02_datasets_integrity(self):
        """Verify that train, validation, test, and unseen datasets exist and match splits."""
        for name, path, min_rows in [
            ("train.csv", config.TRAIN_CSV, 15000),
            ("validation.csv", config.VAL_CSV, 2000),
            ("test.csv", config.TEST_CSV, 5000),
            ("unseen_workload.csv", config.UNSEEN_CSV, 10000),
        ]:
            self.assertTrue(path.exists(), f"{name} does not exist")
            df = pd.read_csv(path)
            self.assertGreaterEqual(len(df), min_rows, f"{name} has fewer rows than expected")
            self.assertIn("target_class", df.columns, f"{name} missing target_class")
            self.assertIn("delta_lag_1", df.columns, f"{name} missing causal lag features")

    def test_03_boundary_safety_managers(self):
        """Verify page and segment boundary logic."""
        from simulation.page_manager import is_valid_page_prefetch, validate_prefetch_candidate
        from simulation.segment_manager import get_segment_info

        # Normal inside page
        self.assertTrue(is_valid_page_prefetch(block=100, delta=1, page_offset=10, dist_to_page_end=53))
        # Forward cross page
        self.assertFalse(is_valid_page_prefetch(block=100, delta=4, page_offset=62, dist_to_page_end=1))
        # Backward cross page
        self.assertFalse(is_valid_page_prefetch(block=100, delta=-4, page_offset=2, dist_to_page_end=61))

        # Full validation
        ok, reason = validate_prefetch_candidate(block=0x10000000 >> 6, delta=4, page_offset=10, dist_to_page_end=53, segment_name="DATA")
        self.assertTrue(ok, f"DATA prefetch should be safe but got {reason}")

        # Segment info check
        seg = get_segment_info(0x10000000 >> 6)
        self.assertTrue(seg["valid"])
        self.assertEqual(seg["name"], "DATA")

    def test_04_cache_simulation_metrics(self):
        """Verify multi-level cache simulator behaves deterministically."""
        from src.cache_simulator import MultiLevelCache
        cache = MultiLevelCache(pq_size=16)
        # Demand access
        res, lat = cache.demand_access(block=100, cycle=0)
        self.assertEqual(res, "DRAM_MISS")
        self.assertGreaterEqual(lat, 200)

        # Same block should hit in L1
        res2, lat2 = cache.demand_access(block=100, cycle=10)
        self.assertEqual(res2, "L1_HIT")
        self.assertEqual(lat2, config.CACHE_CONFIG["L1"]["latency_cycles"])

    def test_05_flask_backend_api(self):
        """Verify all Flask REST endpoints."""
        from backend.app import app
        client = app.test_client()

        # 1. Health
        h = client.get("/api/health")
        self.assertEqual(h.status_code, 200)
        h_data = h.get_json()
        self.assertTrue(h_data["ok"])
        self.assertTrue(h_data["model_loaded"])

        # 2. Results
        r = client.get("/api/results")
        self.assertEqual(r.status_code, 200)
        r_data = r.get_json()
        self.assertIn("summary", r_data)
        self.assertIn("models", r_data)

        # 3. Predict
        p = client.post("/api/predict", json={
            "pc": "0x004010A0",
            "address": "0x10001000",
            "segment": "DATA",
            "delta_history": [4, 4, 4, 4],
            "tau": 0.40
        })
        self.assertEqual(p.status_code, 200)
        p_data = p.get_json()
        self.assertEqual(p_data["status"], "success")
        self.assertIn("predicted_stride", p_data)
        self.assertIn("confidence", p_data)
        self.assertIn("decision", p_data)

        # 4. Simulate
        s = client.post("/api/simulate", json={
            "pattern": "stride",
            "length": 100,
            "tau": 0.40
        })
        self.assertEqual(s.status_code, 200)
        s_data = s.get_json()
        self.assertIn("baseline", s_data)
        self.assertIn("adaptive", s_data)
        self.assertLess(s_data["adaptive"]["amat"], s_data["baseline"]["amat"])


if __name__ == "__main__":
    suite = unittest.TestLoader().loadTestsFromTestCase(TestMemoryPrefetchingIntegration)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
